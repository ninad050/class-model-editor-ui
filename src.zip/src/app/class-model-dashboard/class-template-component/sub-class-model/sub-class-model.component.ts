import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-class-model',
  templateUrl: './sub-class-model.component.html',
  styleUrls: ['./sub-class-model.component.scss']
})
export class SubClassModelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
